package com.wmt.mvpdemo.login.view;

public interface ILoginView {

    void onLoginResult(Boolean result, int code);

    void setError(int errorCode);

    void onLoginFailed();
}
