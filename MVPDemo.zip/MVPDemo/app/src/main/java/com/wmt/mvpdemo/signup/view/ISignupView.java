package com.wmt.mvpdemo.signup.view;

public interface ISignupView {
}
