package com.wmt.mvpdemo.login.presenter;

import android.os.Looper;

import com.wmt.mvpdemo.login.model.IUser;
import com.wmt.mvpdemo.login.model.User;
import com.wmt.mvpdemo.login.view.ILoginView;

import java.util.logging.Handler;

public class LoginPresenter implements ILoginPresenter {

    ILoginView iLoginView;
    IUser user;

    public LoginPresenter(ILoginView iLoginView) {
        initUser();
        this.iLoginView = iLoginView;
    }

    @Override
    public void doLogin(String Email, String Password) {

        //lgon check
        if (validate(Email, Password)) {
            Boolean isLoginSuccess = true;
            final int code = user.checkUserValidity(Email, Password);
            if (code != 0) isLoginSuccess = false;
            final Boolean result = isLoginSuccess;
            iLoginView.onLoginResult(result, code);
        } else {
            iLoginView.onLoginFailed();
        }
    }

    private void initUser() {
        user = new User("Safideraiya7@gmail.com", "1234567890");
    }

    boolean validate(String Email, String Password) {

        if (!android.util.Patterns.EMAIL_ADDRESS.matcher(Email).matches()) {
            iLoginView.setError(101);
        } else {
        }
        if (Password.isEmpty()) {
            iLoginView.setError(102);
        } else {
            if (Password.length() > 5) {
            } else {
                iLoginView.setError(103);
            }
        }
        return true;
    }
}
