package com.wmt.mvpdemo.login;

import android.content.Intent;
import android.support.design.widget.Snackbar;
import android.support.design.widget.TextInputLayout;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.wmt.mvpdemo.MainActivity;
import com.wmt.mvpdemo.R;
import com.wmt.mvpdemo.login.model.User;
import com.wmt.mvpdemo.global.SqliteHelper;
import com.wmt.mvpdemo.login.presenter.LoginPresenter;
import com.wmt.mvpdemo.login.view.ILoginView;
import com.wmt.mvpdemo.signup.SignUpActivity;
import com.wmt.mvpdemo.signup.model.UserR;

import static android.text.Html.fromHtml;

public class LoginActivity extends AppCompatActivity implements ILoginView, View.OnClickListener {

    EditText editTextEmailLogin;
    EditText editTextPasswordLogin;

    TextInputLayout textInputLayoutEmailLogin;
    TextInputLayout textInputLayoutPasswordLogin;

    Button buttonLogin;

    SqliteHelper sqliteHelper;
    private LoginPresenter iLoginPresenter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        sqliteHelper = new SqliteHelper(this);
        editTextEmailLogin = findViewById(R.id.editTextEmailLogin);
        editTextPasswordLogin = findViewById(R.id.editTextPasswordLogin);
        textInputLayoutEmailLogin = findViewById(R.id.textInputLayoutEmailLogin);
        textInputLayoutPasswordLogin = findViewById(R.id.textInputlayoutPasswordLogin);
    iLoginPresenter=new LoginPresenter(this);

        buttonLogin = findViewById(R.id.buttonLogin);
        initCreateAccountTextView();

        buttonLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (validate()) {
                    String Email = editTextEmailLogin.getText().toString();
                    String Password = editTextPasswordLogin.getText().toString();
            iLoginPresenter.doLogin(Email,Password);

            User currentUSer = sqliteHelper.Authenticate(new UserR(Email,Password));
//                    User currentUSer = sqliteHelper.Authenticate(new User(Email,Password));

                    if (currentUSer != null) {
                        Snackbar.make(buttonLogin, "Succesfully login", Snackbar.LENGTH_LONG).show();
                        Intent i = new Intent(LoginActivity.this, MainActivity.class);
                        startActivity(i);

                    } else {
                        Snackbar.make(buttonLogin, "Failed to Login Please try again", Snackbar.LENGTH_LONG).show();
                    }
                }
            }
        });
    }

    private void initCreateAccountTextView() {
        TextView textViewCreateAccount = findViewById(R.id.textViewCreateAccont);
        textViewCreateAccount.setText(fromHtml("<font color='#000000'>I don't have account yet. </font><font color='#008577'>create one</font>"));
        textViewCreateAccount.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(LoginActivity.this, SignUpActivity.class);
                startActivity(intent);
            }
        });
    }
    private boolean validate() {
        boolean valid = false;

        String Email = editTextEmailLogin.getText().toString();
        String Password = editTextPasswordLogin.getText().toString();

        if (!android.util.Patterns.EMAIL_ADDRESS.matcher(Email).matches()) {
            valid = false;
            textInputLayoutEmailLogin.setError("Please enter valid email!");
        } else {
            valid = true;
            textInputLayoutEmailLogin.setError(null);
        }
        if (Password.isEmpty()) {
            valid = false;
            textInputLayoutPasswordLogin.setError("Please enter valid password!");
        } else {
            if (Password.length() > 5) {
                valid = true;
                textInputLayoutPasswordLogin.setError(null);
            } else {
                valid = false;
                textInputLayoutPasswordLogin.setError("Password is to short!");
            }
        }

        return valid;
    }


    @Override
    public void onClick(View v) {
            iLoginPresenter.doLogin(editTextEmailLogin.getText().toString(),editTextEmailLogin.getText().toString());
    }

    @Override
    public void onLoginResult(Boolean result, int code) {

        Toast.makeText(this, "asddsad", Toast.LENGTH_SHORT).show();
    }

    @Override
    public void setError(int errorCode) {
        switch (errorCode)
        {
            case 101:
                textInputLayoutEmailLogin.setError("Enter valid email");
                break;
            case 102:
                textInputLayoutPasswordLogin.setError("Please Enter Valid Password");
            case 103:
                textInputLayoutPasswordLogin.setError("Password is to short!");
        }
    }

    @Override
    public void onLoginFailed() {
        Toast.makeText(this, "Please try Again!", Toast.LENGTH_SHORT).show();
    }
}
