package com.wmt.mvpdemo.signup.model;

public interface IUserR {
}
