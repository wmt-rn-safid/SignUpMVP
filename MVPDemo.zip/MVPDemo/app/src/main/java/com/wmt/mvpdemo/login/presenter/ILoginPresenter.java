package com.wmt.mvpdemo.login.presenter;

public interface ILoginPresenter {

    void doLogin(String Email,String Password);
}
