package com.wmt.mvpdemo.login.model;

public interface IUser {

    String getEmail();
    String getPassword();
    int checkUserValidity(String Email, String Password);
}
