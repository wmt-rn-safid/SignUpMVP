package com.wmt.mvpdemo.signup.presenter;

public interface ISignUpPresenter {
}
