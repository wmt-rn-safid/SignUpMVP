package com.wmt.mvpdemo.login.model;

public class User  implements IUser{

    public String email;
    public String password;

    public User( String email, String password) {

        this.email = email;
        this.password = password;
    }
    public String getEmail() {
        return email;
    }

    public String getPassword() {
        return password;
    }

    @Override
    public int checkUserValidity(String Email, String Password) {
        if (Email==null||Password==null||!Email.equals(getEmail())||!Password.equals(getPassword())){
            return -1;
        }
        return 0;
    }


}
